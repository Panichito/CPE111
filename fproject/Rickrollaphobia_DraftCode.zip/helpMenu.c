//
// Created by ASUS on 3/13/2021.
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "commandFunctions.h"
#include "helpMenu.h"
#include "abstractQueueMod.h"
#include "linkedListUtilMod.h"


typedef struct _command
{
	int modes;
	char Bcom[30];
	char Barg[64];
	struct _command * pNext;
}HELP_T;

void helpFunction(char *input)
{
	char buffer[32];
	char Bcom[32];
	char Barg[32];
	int modes;
	HELP_T * com;
	FILE* inputfile = NULL;
	inputfile = fopen("command.txt","r");
	if (inputfile == NULL)
	{
	    printf("Error opening file - HELP SECTION\n");
	    exit(1);
	}
	while (fgets(buffer,sizeof(buffer),inputfile) != NULL)
	{
		sscanf(buffer,"%d %[^:]:%[^\n]",&modes,Bcom,Barg);
		com->modes = modes;
        strcpy(com->Bcom,Bcom);
        strcpy(com->Barg,Barg);
		com = com->pNext;
	}

	if(input == NULL)
	{
		printallhelp();
	}
	else
	{
		MODE mode = checkCommandMode(input);
		askforhelp(mode);
	}
}

void printallhelp()
{
	char buffer[32];
	char Bcom[32];
	char Barg[32];
	char input[32];
	HELP_T * com;

	int i = 0;

	while(1)
	{
		for(int i = 0 ; i < 5 ; i++)
		{
			if(com != NULL)
			{
				printf("%s arg %s\n",com->Bcom,com->Barg);
				com = com->pNext;
			}
			else
				break;
		}
		printf("do you wish to see more? (Y/N): ");
		fgets(buffer,sizeof(buffer),stdin);
		sscanf(buffer,"%s",input);
		if(strcasecmp(input,"0") == 0)
		{
		printf("here is the lists of command\n");
		}
		else
		{
			break;
		}
		
	}

}

void askforhelp(MODE mode)
{
	HELP_T * com;
	while(1)
	{
		if(mode == ERR)
		{
			printf("Error\n");
			break;
		}
		else if(mode == com->modes)
		{
			printf("command: %s argument %s\n",com->Bcom,com->Barg);
		}
	}
}	