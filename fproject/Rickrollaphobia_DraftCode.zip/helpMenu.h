//
// Created by ASUS on 3/13/2021.
//

#ifndef RICKROLLAPHOBIA_HELPMENU_H
#define RICKROLLAPHOBIA_HELPMENU_H
#include <stdlib.h>
#include <stdio.h>
#include "commandFunctions.h"

/* Structure that represents one item of the list */
typedef struct _listitem
    {
    void *pData;               /* Pointer to the data for this node */
    struct _listitem *pNext;  /* Link to the next item in the list */
    } LISTITEM_T;

void helpFunction(char* input);

void printallhelp();
void askforhelp(MODE mode);

#endif //RICKROLLAPHOBIA_HELPMENU_H
